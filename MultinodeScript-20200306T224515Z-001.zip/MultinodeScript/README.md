# CDP DC via Ansible

## Assumptions and Limitations

- Only works for bare metals (untested), AWS and OpenStack.
- doesn't setup indentity servers other than MIT KDC (freeipa coming soon).
- not tested to install CDH 5 or 6.

## Description

This GitHub repo contains Ansible playbooks and tasks files to provision a stock CDH or CDP DC cluster. The cluster can be deployed on bare metal, OpenStack or Public Cloud instances.

The main playbook is `cdp-dc.yml`, which is called from the default entry playbook `site.yml`. You can edit `site.yml` to do more than just create a CDP/CDH cluster, for example, you can invoke other playbooks or tasks to be executed before or after `cdp-dc.yml`.

**NOTE**: playbooks are always executed **sequentially**, never **concurrently**. If you want to run multiple playbooks in parallel, then you need to run each playbook in a separate shell, example:

```bash
shell-1 $> ansible-playbook load_balancers.yml  > log1
shell-2 $> ansible-playbook webservers.yml  > log2
shell-3 $> ansible-playbook dbservers.yml  > log3
```

You pass 5 parameters to `site.yml`:

- the filepath of the infrastructure file, if not deploying on bare metal.
- the filepath of the CM and cluster definition file.
- the filepath of the Vault file, where your sensitive variables are stored.
- variable `cdpdc_teardown`: a unique string identifier for your deployment
- the public key name used by the cloud provider.

## Prerequisites

1. You need to setup Ansible on your machine. Check how to do that [here](https://gist.github.com/fabiog1901/bbc22d91a556e16ebae8b1a90e1881fc).

2. You also need to add the ssh private key into your `ssh-agent`. Some info on how to do that is [here](http://sshkeychain.sourceforge.net/mirrors/SSH-with-Keys-HOWTO/SSH-with-Keys-HOWTO-6.html).

3. Create the Ansible Vault file to store the private key. This is required by CM when it comes to install the CM Agent on all hosts. We keep this variable in a Vault, which is encrypted.

    ```bash
    ansible-vault create ~/keys.vault
    ```

    This will open up an editor similar to **vi**. Insert the private key as below example, making sure you pay close attention at the indentation:

    ```bash
    fabio_key: |
      -----BEGIN RSA PRIVATE KEY-----
      Madsfdasagafgfdgfdsgadhdjasvfgaertqrecsf
      [...]
      dfasdgretwreaqghaduogihafdkghareoighfdk=
      -----END RSA PRIVATE KEY-----
    ```

    You will be asked to enter a password. Save the password for later.

    If you want to view or edit the file, use `ansible-vault view` or `ansible-vault edit`.

    Let's now create a simple file to store the Vault password, so you won't be prompted at runtime, and lock it.

    ```bash
    echo "YourPassword" > vault-password-file
    chmod 400 vault-password-file
    ```

4. Set below properties in your Ansible config file (eg on `/etc/ansible/ansible.cfg`, but there are many places where you can put your config):

    ```bash
    host_key_checking = False
    vault_password_file = /path/to/your/vault-password-file
    # optional
    log_path = /path/to/ansible.log
    stdout_callback = yaml
    ```

5. Add below to your Ansible hosts file (eg on `/etc/ansible/hosts`. This is the default location).

    ```bash
    [local]
    localhost
    ```

6. Export the required AWS or Openstack keys if you plan to deploy on these platforms.

    ```bash
    export AWS_ACCESS_KEY_ID=XXXXYYYYZZZZ
    export AWS_SECRET_ACCESS_KEY=xxxxxxxxxxxxyyyyyyyyyyyyzzzzzzz
    ````

## Instructions

1. Clone this repo.

    ```bash
    cd ~
    git clone https://github.infra.cloudera.com/GOES/xxx.git
    cd xxx
    ```

2. Build your `infra` and `cluster` files. More info on these files is below.

3. If you are running on bare metal servers, then you don't need to pass the `infra` file (as you already have your infrastructure created) but you need to write your Ansible inventory file, see file `ansible_hosts.yml` as an example.

4. Run the playbook, change filepath and `cdpdc_teardown` code accordingly:

    ```bash
    ansible-galaxy install -r requirements.yml -p roles/
    ansible-playbook site.yml \
      --extra-vars "infra=/path/to/your/infra/file" \
      --extra-vars "cluster=/path/to/your/cluster/file" \
      --extra-vars "vault=~/keys.vault" \
      --extra-vars "cdpdc_teardown=your-unique-identifier-like-name-timestamp" \
      --extra-vars "public_key=your-public-key-id"
    ```

    For OSX, you might have to specify the Python interpreter explicitly by adding `--extra-vars 'ansible_python_interpreter=/usr/local/bin/python3'` to the above command.

## How it works

Playbook `site.yml` executes the following plays, in order:

1. PROVISION HOSTS AND BUILD ANSIBLE HOSTS INVENTORY.

    The goal is to end up with an Ansible inventory file. If you are running CDH/CDP on bare metal server, then your servers are already provisioned and all you need to do is to write the inventory file yourself, see `ansible_hosts.yml` as example to guide you on what groups and variables to use. Particularly, each host should include these 4 variables:

    - private_hostname
    - private_ip
    - public_hostname
    - public_ip

    These variables are useful later to write your `cluster` file.

    If you are deploying on OpenStack or the Public Cloud, then you need to supply the `infra` file. This file lists the instances to provision and the groups they should be assigned to. Check the sample infra file `stock.infra.yml` as an example. All hosts should be part of group `cdpdc`.

    Once this play is complete, you'll have your infrastructure provisioned and the Ansible inventory ready with groups and hosts.

2. INSTALL RDBMS

    This play invokes a Role to create your RDBMS to store the databases required by CM in the host in group `db_server`.
    Currently, only MariaDB 10.1 is supported, but this role can be extended to install the other supported databases, eg: Oracle, PGSQL or MySQL.

3. INSTALL MIT KDC SERVER

    This role to install MIT KDC server in the host in group `krb5_server`. In the future, this role can be expanded to include FreeIPA.

4. INSTALL MIT KDC CLIENT

    This role to install the client libs for MIT KDC server on all servers in group `cdpdc`.

5. PROVISION A CDP-DC CLUSTER

    This play invokes another playbook, `cdp-dc.yml` which holds all the plays required to install a full CDP cluster.

Playbook `cdp-dc.yml` list of plays:

1. Configure the OS, and this applies to all hosts (inventory group `cdpdc`).

2. Create databases on the RDBMS installed on host in group `db_server`. The details of what databases to create are specified in the `cluster` file.

3. Install SMM requirements on host in group `cdf`. Note that if you don't have a `cdf` group, Ansible will simply skip this play. This play invokes tasks from another file, but ideally it should use a Role instead.

4. Install CEM on host in group `cdf`. This play invokes tasks from another file, but ideally it should use a Role instead.

5. Install CM server on host in group `cm_server`. This play uses the `cluster` file, needed by CM to read the cluster template to build the cluster.

    Read file `stock.cluster.yml` as example to build your `cluster` file. This file includes:
    - CM login details.
    - details of the databases to setup,
    - repos to use to install CM,
    - urls to download CSDs and parcel files.
    - a section to list CSDs and parcel files to upload from your machine,
    - the cluster template imported by CM to build your cluster.

    Note that in the cluster template file you can place variables that reference specific hosts. For example, you want the CDSW Url to be <cdsw.IPADDRESS.nip.io>. You do this in the *services > serviceConfigs (for CDSW) > name: cdsw.domain.config*.
    How do you know what IP address the CDSW Master will have, if you haven't instantiated the instance yet?

    `groups` is a **magic** variable that holds a dictionary where the keys are the inventory groups and the value is a list of hosts. So `groups.cdsw_master[0]` will return the first (and only) host in group `cdsw_master`.

    `hostvars` is another **magic** variable that holds a dictionary with all info about the hosts in the inventory file. The keys of the dictionary are the ansible host names, so `hostvars['123.123.10.25']` will return a dictionary with all variables for that host.

    You can leverage these 2 magic variables to find out what the public IP address of the CDSW master will be: `hostvars[groups.cdsw_master[0]].public_ip`.

### Examples

Spinning up Ali's WWBank demo:

```bash
ansible-playbook wwbank.site.yml \
    -e "infra=config/wwbank.infra.openstack.yml" \
    -e "cluster=config/wwbank.cluster.yml" \
    -e "vault=~/keys.vault" \
    -e "cdpdc_teardown=fabiowwbank" \
    -e "public_key=fabio"
```

Spinning up mini cluster (Auto-TLS, KRB, Encryption):

```bash
ansible-playbook site.yml \
    -e "infra=config/mini.infra.openstack.yml" \
    -e "cluster=config/mini.cluster.krb.yml" \
    -e "vault=~/keys.vault" \
    -e "cdpdc_teardown=fabiomini" \
    -e "public_key=fabio"
```
